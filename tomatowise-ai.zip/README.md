# 🍅 TomatoWise – AI Assistant for Nigerian Tomato Farmers

TomatoWise is an AI-powered assistant designed to help Nigerian tomato farmers get real-time advice on farm issues, pest/disease diagnosis, and market prices – now with voice input and audio output in **English**, **Hausa**, and **Yoruba**.

## 🎯 Features

✅ Ask farming questions via text or **voice input**  
✅ AI-generated advice powered by **GPT-3.5**  
✅ Supports multiple languages: **English, Hausa, Yoruba**  
✅ Listen to advice using **text-to-speech audio**  
✅ Simulated real-time **tomato market prices**  

## 🛠️ Tech Stack

- Streamlit – UI framework  
- OpenAI GPT-3.5 – AI brain  
- gTTS – text-to-speech  
- SpeechRecognition + Pydub – voice input  
- ffmpeg – for audio file handling (needed locally)

## 🚀 Try It Live

[🔗 Live Demo](https://your-app-name.streamlit.app)

## 🧪 Run Locally

1. Clone the repository
```bash
git clone https://github.com/yourusername/tomatowise-ai.git
cd tomatowise-ai
```

2. Create `.streamlit/secrets.toml` and add:
```toml
OPENAI_API_KEY = "your-api-key-here"
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the app:
```bash
streamlit run app.py
```

## 🙋‍♂️ Built By

**Wilson Idzi** – 3MTT Fellow  
[@3MTTNigeria](https://twitter.com/3MTTNigeria)  
🏷️ #3MTTLearningCommunity #Му3МТТ

## 📄 License

Open-source for educational and agricultural empowerment.
